# 5-Minute Razorpay Buildathon Demo Script

## 0:00–0:30 — The problem

“Hi, I’m [your name]. This is RazorRecon, my Razorpay AI Buildathon submission for the AI Finance Controller track. Settlement reconciliation is a time-consuming finance-operations problem: merchant orders and payout records often differ because of fees, bundles, reserve holds, and missing payouts. The risk is worse than slow work — a wrong automatic match can create a financial error.”

## 0:30–1:05 — The product

“RazorRecon automates the safe cases and makes uncertainty visible. It runs locally with no API key and no external financial calls. This dashboard opens with one command: `python -m src.web`. I’ll run a reconciliation now.”

**On screen:** Click **Run reconciliation**.

## 1:05–1:55 — Exact-match layer

“The first layer is intentionally strict. It automatically clears only a single-order payout whose amount matches exactly, using Decimal-based money comparison. A one-paisa difference, a bundle, an unknown order, or an order duplicated across payouts is not guessed. It is held for investigation or review, which prevents double counting.”

**On screen:** Point at an `EXACT MATCH` settlement.

## 1:55–3:00 — MCP and reasoning

“Unresolved cases go through a local MCP server, which is the controlled data boundary. The agent cannot read raw input files. It can only access the unresolved hand-off and use read-only tools to calculate variance, fetch the local fee schedule, and simulate tax on a fee.

The default reasoning engine is reproducible and auditable. It can safely recognise an unitemized gateway-fee pattern or a bundled settlement whose order total matches the payout. Every decision is confidence-gated.”

## 3:00–3:45 — Honest exceptions

“The exception queue is a core feature. For example, a reserve hold may look explainable, but it is a timing difference and this system cannot prove when it will be released. So it is never silently reconciled. Low-confidence and unexplained cases are routed to a human with the evidence and recommended action.”

**On screen:** Show one exception and its confidence badge.

## 3:45–4:35 — Outputs and ML option

“Every run creates a reconciled ledger, an honest exceptions list, and a readable audit trail. I also included an optional locally trained ML classifier for edge cases. Training and serving share one feature extractor, preventing train-serve drift. Even then, financial policy still blocks unsafe categories from auto-resolution.”

**On screen:** Open `data/audit_trail.md` after a run.

## 4:35–5:00 — Close

“RazorRecon gives finance teams a safe local workflow: exact matches are quick, explainable cases are assisted, and uncertainty is surfaced instead of hidden. The repository includes the dashboard, synthetic data generator, tests, full setup guide, and this demo script. Thank you.”
